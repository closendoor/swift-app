import ComposableArchitecture

extension ChatFeature {
    @ObservableState
    struct State {

    }
}
