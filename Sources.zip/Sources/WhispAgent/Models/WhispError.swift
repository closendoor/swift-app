enum WhispError: Error {
    case notInitialized
}
